from django.apps import AppConfig


class ThecodingConfig(AppConfig):
    name = 'thecoding'
